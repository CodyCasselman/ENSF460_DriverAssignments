
# Project 2 Python Instructions

1. Ensure all other port users for COM3 (Ex. Realterm) are closed
2. Start the Python program
3. Start the C program
4. Test away

