/* 
 * File:   ADC.h
 * Authors: Cody C, Evan M, Keeryn J
 */

#ifndef ADC_H
#define	ADC_H

#include <xc.h> 

void ADCInit();
uint16_t do_ADC(void);

#endif	/* ADC_H */

