/* 
 * File:   IOS.h
 * Authors: Cody C, Evan M, Keeryn J
 */

#ifndef IOS_H
#define IOS_H

#include <xc.h>

void IOInit();
uint8_t IOCheck();


#endif
